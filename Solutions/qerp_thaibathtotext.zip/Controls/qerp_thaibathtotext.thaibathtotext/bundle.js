/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./thaibathtotext/index.ts":
/*!*********************************!*\
  !*** ./thaibathtotext/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   thaibathtotext: () => (/* binding */ thaibathtotext)\n/* harmony export */ });\n/* harmony import */ var bahttext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bahttext */ \"./node_modules/bahttext/src/index.js\");\n/* harmony import */ var bahttext__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bahttext__WEBPACK_IMPORTED_MODULE_0__);\n\nclass thaibathtotext {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  updateView(context) {\n    // Get the input value from the property\n    var inputValue = context.parameters.inputThaiBath.raw;\n    if (inputValue !== null && inputValue !== undefined) {\n      // Convert the input value to Thai Baht text\n      this._value = (0,bahttext__WEBPACK_IMPORTED_MODULE_0__.bahttext)(inputValue);\n    } else {\n      this._value = \"\";\n    }\n    // Notify the framework that the output has changed\n    this._notifyOutputChanged();\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    return {\n      outputThaiBath: this._value\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./thaibathtotext/index.ts?");

/***/ }),

/***/ "./node_modules/bahttext/src/index.js":
/*!********************************************!*\
  !*** ./node_modules/bahttext/src/index.js ***!
  \********************************************/
/***/ ((module, exports) => {

eval("var bahtxtConst = {\n  defaultResult: 'ศูนย์บาทถ้วน',\n  singleUnitStrs: ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'],\n  placeNameStrs: ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน']\n};\n\n/**\n * @private\n * @param {number[]} nums\n * @returns {string}\n */\nfunction bahtxtNum2Word(nums) {\n  var result = '';\n  var len = nums.length;\n  var maxLen = 7;\n  if (len > maxLen) {\n    // more than million\n    var overflowIndex = len - maxLen + 1;\n    var overflowNums = nums.slice(0, overflowIndex);\n    var remainingNumbs = nums.slice(overflowIndex);\n    return bahtxtNum2Word(overflowNums) + 'ล้าน' + bahtxtNum2Word(remainingNumbs);\n  } else {\n    for (var i = 0; i < len; i++) {\n      var digit = nums[i];\n      if (digit > 0) {\n        result += bahtxtConst.singleUnitStrs[digit] + bahtxtConst.placeNameStrs[len - i - 1];\n      }\n    }\n  }\n  return result;\n}\n\n/**\n * @private\n * @todo improve performance\n * @param {string} str\n * @returns {string}\n */\nfunction bahtxtGrammarFix(str) {\n  return str.replace(/หนึ่งสิบ/g, 'สิบ').replace(/สองสิบ/g, 'ยี่สิบ').replace(/สิบหนึ่ง/g, 'สิบเอ็ด');\n}\n\n/**\n * bahtxtCombine baht and satang\n * and also adding unit\n *\n * @private\n * @param {string} baht\n * @param {string} satang\n * @returns {string}\n */\nfunction bahtxtCombine(baht, satang) {\n  if (!baht && !satang) {\n    return bahtxtConst.defaultResult;\n  } else if (baht && !satang) {\n    return baht + 'บาท' + 'ถ้วน';\n  } else if (!baht && satang) {\n    return satang + 'สตางค์';\n  } else {\n    return baht + 'บาท' + satang + 'สตางค์';\n  }\n}\n\n/**\n * Change number to Thai pronunciation string\n *\n * @public\n * @param {number} num\n * @returns {string}\n */\nfunction bahttext(num) {\n  if (!num ||\n  // no null\n  typeof num === 'boolean' ||\n  // no boolean\n  isNaN(Number(num)) ||\n  // must be number only\n  num < Number.MIN_SAFE_INTEGER ||\n  // not less than Number.MIN_SAFE_INTEGER\n  num > Number.MAX_SAFE_INTEGER // no more than Number.MAX_SAFE_INTEGER\n  ) {\n    return bahtxtConst.defaultResult;\n  }\n\n  // set\n  var positiveNum = Math.abs(num);\n\n  // split baht and satang e.g. 432.214567 >> 432, 21\n  var bahtStr = Math.floor(positiveNum).toString();\n  /** @type {string} */\n  var satangStr = (positiveNum % 1 * 100).toFixed(0);\n\n  /** @type {number[]} */\n  var bahtArr = Array.from(bahtStr).map(Number);\n  /** @type {number[]} */\n  var satangArr = Array.from(satangStr).map(Number);\n\n  // proceed\n  var baht = bahtxtNum2Word(bahtArr);\n  var satang = bahtxtNum2Word(satangArr);\n\n  // grammar\n  baht = bahtxtGrammarFix(baht);\n  satang = bahtxtGrammarFix(satang);\n\n  // combine\n  var result = bahtxtCombine(baht, satang);\n  return num >= 0 ? result : 'ลบ' + result;\n}\nif ( true && module.exports != null) {\n  module.exports = {\n    bahttext,\n    // export for testing only\n    bahtxtNum2Word,\n    bahtxtGrammarFix,\n    bahtxtCombine\n  };\n  exports[\"default\"] = {\n    bahttext\n  };\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/bahttext/src/index.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./thaibathtotext/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('thaibathtotext.thaibathtotext', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.thaibathtotext);
} else {
	var thaibathtotext = thaibathtotext || {};
	thaibathtotext.thaibathtotext = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.thaibathtotext;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}